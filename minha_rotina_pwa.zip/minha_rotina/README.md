# Minha Rotina 💗

Aplicativo web responsivo e instalável (PWA), sem frameworks nem etapa de compilação.

## Arquivos
- `index.html`: interface e funcionalidades.
- `manifest.json`: metadados para instalação.
- `sw.js`: cache básico para uso offline após o primeiro carregamento.
- `assets/foto-casal.jpeg`: foto enviada, mantida sem edição.
- `assets/icon.svg`: ícone do aplicativo.

## Publicar no GitHub Pages
1. Entre em https://github.com e crie um repositório novo, por exemplo `minha-rotina`. Para facilitar, deixe-o **Public** e não marque para criar README automaticamente.
2. Descompacte o ZIP no computador/celular. Abra a pasta `minha_rotina`.
3. Dentro do repositório, use **Add file → Upload files** (ou **Add file → Create new file**, se for enviar arquivos individualmente). Envie `index.html`, `manifest.json`, `sw.js` e a pasta `assets` com os dois arquivos dentro. O `index.html` precisa ficar na raiz do repositório, não dentro de outra pasta.
4. Escreva uma mensagem no campo de commit e toque em **Commit changes**.
5. No repositório, abra **Settings → Pages**.
6. Em **Build and deployment**, selecione **Deploy from a branch**. Escolha `main` e a pasta `/(root)` e salve.
7. Aguarde a publicação. O GitHub mostrará um endereço parecido com `https://SEU-USUARIO.github.io/minha-rotina/`. Abra esse endereço.
8. Para atualizações, envie os arquivos alterados e faça commit. Se o app já estiver instalado, feche e reabra; o cache pode levar um pouco para atualizar.

## Adicionar à tela inicial
- **Android (Chrome):** abra o endereço HTTPS publicado, toque no menu ⋮ e escolha **Instalar app** ou **Adicionar à tela inicial**.
- **iPhone (Safari):** abra o endereço no Safari, toque em **Compartilhar** e escolha **Adicionar à Tela de Início**.

## Dados e privacidade
- Rotina, água, refeições, estudos, treinos, livros e lembranças são salvos no `localStorage` do navegador neste dispositivo.
- Os dados não sincronizam automaticamente entre aparelhos. Use **Dados → Exportar backup** e guarde o arquivo JSON num local seguro.
- Importar um backup substitui os dados atuais, após confirmação. “Apagar todos os dados” também pede confirmação.
- Não há conta, senha ou servidor de dados. Evite apagar os dados do site/navegador antes de exportar um backup.

## Observações
- O app usa horários e metas iniciais editáveis. A rotina é uma sugestão, não uma prescrição de saúde.
- Para funcionamento offline, abra o site publicado com conexão pelo menos uma vez e aguarde o service worker instalar.
- Em alguns navegadores, a instalação PWA pode aparecer com nomes diferentes.
